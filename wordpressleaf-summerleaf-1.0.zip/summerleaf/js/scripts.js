eval(function(p,a,c,k,e,r){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)r[e(c)]=k[c]||e(c);k=[function(e){return r[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('(5(a){4(1t 1l!=="1h"&&1l.2z){1l([],a)}X{4(1t 1y!=="1h"&&1y.1G){1y.1G=a()}X{13.1O=a()}}})(5(){3 c=5(){11 13.23||(Z.18&&Z.18.1X)||Z.1k.1X};3 G={};3 V=24;3 k=[];3 E="25";3 B="26";3 z="28";3 o="2i";3 l="2j";3 w="2l";3 n="2m";3 p=[E,B,z,o,l,w,n];3 F={7:0,6:0};3 y=5(){11 13.22||Z.18.1L};3 a=5(){11 2o.2q(Z.1k.1I,Z.18.1I,Z.1k.1w,Z.18.1w,Z.18.1L)};G.15=1d;G.1b=1d;G.1a=1d;G.1A=y();3 v;3 s;3 b;5 t(){G.15=c();G.1b=G.15+G.1A;G.1a=a();4(G.1a!==v){b=k.Y;1i(b--){k[b].1j()}v=G.1a}}5 r(){G.1A=y();t();q()}3 d;5 u(){2r(d);d=2y(r,2B)}3 h;5 q(){h=k.Y;1i(h--){k[h].19()}h=k.Y;1i(h--){k[h].1D()}}5 m(P,I){3 S=2;2.9=P;4(!I){2.16=F}X{4(I===+I){2.16={7:I,6:I}}X{2.16={7:I.7||F.7,6:I.6||F.6}}}2.8={};1c(3 N=0,M=p.Y;N<M;N++){S.8[p[N]]=[]}2.1e=1o;3 L;3 Q;3 R;3 O;3 H;3 e;5 K(i){4(i.Y===0){11}H=i.Y;1i(H--){e=i[H];e.1q.1p(S,s);4(e.1E){i.1m(H,1)}}}2.1D=5 J(){4(2.W&&!L){K(2.8[B])}4(2.14&&!Q){K(2.8[z])}4(2.12!==R&&2.17!==O){K(2.8[E]);4(!Q&&!2.14){K(2.8[z]);K(2.8[l])}4(!L&&!2.W){K(2.8[B]);K(2.8[o])}}4(!2.14&&Q){K(2.8[l])}4(!2.W&&L){K(2.8[o])}4(2.W!==L){K(2.8[E])}1K(1g){10 L!==2.W:10 Q!==2.14:10 R!==2.12:10 O!==2.17:K(2.8[n])}L=2.W;Q=2.14;R=2.12;O=2.17};2.1j=5(){4(2.1e){11}3 U=2.7;3 T=2.6;4(2.9.2k){3 j=2.9.1z.1x;4(j==="1Q"){2.9.1z.1x=""}3 i=2.9.27();2.7=i.7+G.15;2.6=i.6+G.15;4(j==="1Q"){2.9.1z.1x=j}}X{4(2.9===+2.9){4(2.9>0){2.7=2.6=2.9}X{2.7=2.6=G.1a-2.9}}X{2.7=2.9.7;2.6=2.9.6}}2.7-=2.16.7;2.6+=2.16.6;2.1u=2.6-2.7;4((U!==1h||T!==1h)&&(2.7!==U||2.6!==T)){K(2.8[w])}};2.1j();2.19();L=2.W;Q=2.14;R=2.12;O=2.17}m.1S={1s:5(e,j,i){1K(1g){10 e===E&&!2.W&&2.12:10 e===B&&2.W:10 e===z&&2.14:10 e===o&&2.12&&!2.W:10 e===l&&2.12:j.1p(2,s);4(i){11}}4(2.8[e]){2.8[e].1U({1q:j,1E:i||1o})}X{1n 1f 1B("1Y 1Z 2n a 1v 21 20 1W 1V "+e+". 1T 1C 1R: "+p.1P(", "))}},29:5(H,I){4(2.8[H]){1c(3 e=0,j;j=2.8[H][e];e++){4(j.1q===I){2.8[H].1m(e,1);2a}}}X{1n 1f 1B("1Y 1Z 2b a 1v 21 20 1W 1V "+H+". 1T 1C 1R: "+p.1P(", "))}},2c:5(e,i){2.1s(e,i,1g)},2d:5(){2.1u=2.9.1w+2.16.7+2.16.6;2.6=2.7+2.1u},19:5(){2.12=2.7<G.15;2.17=2.6>G.1b;2.W=(2.7<=G.1b&&2.6>=G.15);2.14=(2.7>=G.15&&2.6<=G.1b)||(2.12&&2.17)},2e:5(){3 I=k.2f(2),e=2;k.1m(I,1);1c(3 J=0,H=p.Y;J<H;J++){e.8[p[J]].Y=0}},2g:5(){2.1e=1g},2h:5(){2.1e=1o}};3 g=5(e){11 5(j,i){2.1s.1p(2,e,j,i)}};1c(3 C=0,A=p.Y;C<A;C++){3 f=p[C];m.1S[f]=g(f)}1N{t()}1M(D){1N{13.$(t)}1M(D){1n 1f 1B("2p 1J 1H 2s 1O 2t 2u <2v>, 1J 1H 2w 2x.")}}5 x(e){s=e;t();q()}4(13.1r){13.1r("1v",x);13.1r("2A",u)}X{13.1F("2C",x);13.1F("2D",u)}G.2E=G.2F=5(i,j){4(1t i==="2G"){i=Z.2H(i)}X{4(i&&i.Y>0){i=i[0]}}3 e=1f m(i,j);k.1U(e);e.19();11 e};G.19=5(){s=1d;t();q()};G.2I=5(){G.1a=0;G.19()};11 G});',62,169,'||this|var|if|function|bottom|top|callbacks|watchItem|||||||||||||||||||||||||||||||||||||||||||||||||isInViewport|else|length|document|case|return|isAboveViewport|window|isFullyInViewport|viewportTop|offsets|isBelowViewport|documentElement|update|documentHeight|viewportBottom|for|null|locked|new|true|undefined|while|recalculateLocation|body|define|splice|throw|false|call|callback|addEventListener|on|typeof|height|scroll|offsetHeight|display|module|style|viewportHeight|Error|options|triggerCallbacks|isOne|attachEvent|exports|must|scrollHeight|you|switch|clientHeight|catch|try|scrollMonitor|join|none|are|prototype|Your|push|type|of|scrollTop|Tried|to|listener|monitor|innerHeight|pageYOffset|87|visibilityChange|enterViewport|getBoundingClientRect|fullyEnterViewport|off|break|remove|one|recalculateSize|destroy|indexOf|lock|unlock|exitViewport|partiallyExitViewport|nodeName|locationChange|stateChange|add|Math|If|max|clearTimeout|put|in|the|head|use|jQuery|setTimeout|amd|resize|100|onscroll|onresize|beget|create|string|querySelector|recalculateLocations'.split('|'),0,{}))

//*********************************************************
//*********************************************************
// 目的：    设置Cookie
// 输入：    sName, sValue,iExpireDays
// 返回：    无
//*********************************************************
function SetCookie(sName, sValue,iExpireDays) {
	if (iExpireDays){
		var dExpire = new Date();
		dExpire.setTime(dExpire.getTime()+parseInt(iExpireDays*24*60*60*1000));
		document.cookie = sName + "=" + escape(sValue) + "; expires=" + dExpire.toGMTString()+ "; path=/;domain=zhangge.net";
	}
	else{
		document.cookie = sName + "=" + escape(sValue)+ "; path=/;domain=zhangge.net";
	}
}
 
//*********************************************************
//*********************************************************
// 目的：    返回Cookie
// 输入：    Name
// 返回：    Cookie值
//*********************************************************
function GetCookie(sName) {
	var arr = document.cookie.match(new RegExp("(^| )"+sName+"=([^;]*)(;|$)"));
	if(arr != null){return unescape(arr[2])};
	return null;
 
}


$(document).ready(function() {
	// 跟随
	var $account = $('#sidebar');
	var $header = $('.sidebar-roll');
	var $minisb = $('#content');
	var $footer = $('#footer');

	var accountWatcher = scrollMonitor.create($account);
	var headerWatcher = scrollMonitor.create($header);

	var footerWatcherTop = $minisb.height() + $header.height();

	accountWatcher.lock();
	headerWatcher.lock();

	accountWatcher.visibilityChange(function() {
		$header.toggleClass('follow', !accountWatcher.isInViewport);
	});
});

$(document).ready(function(){
	$("#group-tab span:first").addClass("group-current");
	$("#group-tab .tab-bd-con:gt(0)").hide();
	$("#group-tab span").mouseover(function(){
	$(this).addClass("group-current").siblings("span").removeClass("group-current");
	$("#group-tab .group-tab-bd-con:eq("+$(this).index()+")").show().siblings(".group-tab-bd-con").hide().addClass("group-current");
	});

	$("#layout-tab span:first").addClass("current");
	$("#layout-tab .tab-bd-con:gt(0)").hide();
	$("#layout-tab span").mouseover(function(){
	$(this).addClass("current").siblings("span").removeClass("current");
	$("#layout-tab .tab-bd-con:eq("+$(this).index()+")").show().siblings(".tab-bd-con").hide().addClass("current");
	});

	$("#img-tab span:first").addClass("img-current");
	$("#img-tab .tab-bd-con:gt(0)").hide();
	$("#img-tab span").mouseover(function(){
	$(this).addClass("img-current").siblings("span").removeClass("img-current");
	$("#img-tab .img-tab-bd-con:eq("+$(this).index()+")").show().siblings(".img-tab-bd-con").hide().addClass("img-current");
	});

	$("#login-tab span:first").addClass("login-current");
	$("#login-tab .login-tab-bd-con:gt(0)").hide();
	$("#login-tab span").mouseover(function(){
	$(this).addClass("login-current").siblings("span").removeClass("login-current");
	$("#login-tab .login-tab-bd-con:eq("+$(this).index()+")").show().siblings(".login-tab-bd-con").hide().addClass("login-current");
	});


});

$(document).ready(function() {


// 菜单
$(".nav-mobile").click(function() {
	$("#mobile-nav").slideToggle(500);
});

// 引用
$(".backs").click(function() {
	$(".track").slideToggle("slow");
	return false;
});



$(".qqonline").mouseover(function() {
	$(this).children(".qqonline-box").show();
})
$(".qqonline").mouseout(function() {
	$(this).children(".qqonline-box").hide();
});

$(".orderby").mouseover(function() {
	$(this).children(".order-box").show();
})
$(".orderby").mouseout(function() {
	$(this).children(".order-box").hide();
});

$(".user-box").mouseover(function() {
	$(this).children(".user-info").show();
})
$(".user-box").mouseout(function() {
	$(this).children(".user-info").hide();
});

$('img').error(function(){
    $(this).attr('src',"//zhangge.net/wp-content/themes/begin/img/random/24.jpg");
});

// 分享
if(/iphone|ipod|ipad|ipad|mobile/i.test(navigator.userAgent.toLowerCase())){	
	$('.share-sd').click(function() {
		$('#share').animate({
			opacity: 'toggle',
			top: '-80px'
		},
			500).animate({
			top: '-60px'
		},
		'fast');
		return false;
	});
} else {
	$(".share-sd").mouseover(function() {
		$(this).children("#share").show();
	});
	$(".share-sd").mouseout(function() {
		$(this).children("#share").hide();
	});
}

// 关闭
$('.shut-error').click(function() {
	$('.user_error').animate({
		opacity: 'toggle'
	},
	100);
	return false;
});

// 文字展开
$(".show-more span").click(function(e) {
	$(this).html(["<i class='fa fa-plus-square'></i>展开", "<i class='fa fa-minus-square'></i>折叠"][this.hutia ^= 1]);
	$(this.parentNode.parentNode).next().slideToggle();
	e.preventDefault();
});



// 去边线
$(".message-widget li:last, .message-page li:last, .hot_commend li:last, .search-page li:last, .my-comment li:last").css("border", "none");

// 表情
$('.emoji').click(function() {
	$('.emoji-box').animate({
		opacity: 'toggle',
		left: '50px'
	},
	1000).animate({
		left: '10px'
	},
	'fast');
	return false;
});

// 登录
$('#login-main, #login-mobile, #login-see').leanModal({
	top: 110,
	overlay: 0.6,
	closeButton: '.hidemodal'
});

// 字号
$("#fontsize").click(function() {
	var _this = $(this);
	var _t = $(".single-content");
	var _c = _this.attr("class");
	if (_c == "size_s") {
		_this.removeClass("size_s").addClass("size_l");
		_this.text("A+");
		_t.removeClass("fontsmall").addClass("fontlarge");
	} else {
		_this.removeClass("size_l").addClass("size_s");
		_this.text("A-");
		_t.removeClass("fontlarge").addClass("fontsmall");
	};
});

// 目录
if (document.body.clientWidth > 1024) {
	$(function() {
		$(window).scroll(function() {
			if ($("#log-box").html() != undefined) {
				var h = $("#title-2").offset().top;
				if ($(this).scrollTop() > h && $(this).scrollTop() < h + 50) {
					$("#log-box").show();
				}
				var h = $("#title-1").offset().top;
				if ($(this).scrollTop() > h && $(this).scrollTop() < h + 50) {
					$("#log-box").hide();
				}
			}
		});
	})
}

$(".log-button, .log-close").click(function() {
	$("#log-box").fadeToggle(300);
});

if ($("#log-box").length > 0) {
	$(".log").removeClass("log-no");
}
$('.log-prompt').show().delay(5000).fadeOut();

// 图片延迟
$(".load img, .single-content img,.avatar").lazyload({
	effect: "fadeIn",
	threshold: 100,
	failure_limit: 70
});
$("#gallery img").lazyload({
	event: "mouseover"
});

// 锚链接
$('#catalog a[href*=#],area[href*=#]').click(function() {
	if (location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') && location.hostname == this.hostname) {
		var $target = $(this.hash);
		$target = $target.length && $target || $('[name=' + this.hash.slice(1) + ']');
		if ($target.length) {
			var targetOffset = $target.offset().top;
			$('html,body').animate({
				scrollTop: targetOffset
			},
			800);
			return false;
		}
	}
});

// 图片数量
var i = $('.slide-h .fancybox').size();
$('.myimg').html(' ' + i + ' 张图片');

var i = $('.slides-h .fancybox').size();
$('.mimg').html(' ' + i + ' 张图片');

// 标签背景
box_width=$(".single-tag").width();
len=$(".single-tag ul li a").length-1;
$(".single-tag ul li a").each(function(i){
	var let = new Array('c3010a','31ac76','ea4563','31a6a0','8e7daa','4fad7b','f99f13','f85200','666666');
	var random1 = Math.floor(Math.random()*9)+0;
	var  num=Math.floor(Math.random()*6+9);
	$(this).attr('style','background:#'+let[random1]+'');
	if($(this).next().length>0){last=$(this).next().position().left;}
});

// 按钮clear
$(".single-content").find(".down-line:last").css({clear:"both"});

// 结束
});



// 隐藏侧边
function pr() {
	var R = document.getElementById("sidebar");
	var L = document.getElementById("primary");
	if (R.className == "sidebar") {
		R.className = "sidebar-hide";
		L.className = "";
	} else {
		R.className = "sidebar";
		L.className = "primary";
	}
}

// 评论贴图
function embedImage() {
	var URL = prompt('请输入图片 URL 地址:', 'http://');
	if (URL) {
		document.getElementById('comment').value = document.getElementById('comment').value + '' + URL + '';
	}
};
// 文字滚动
(function($) {
	$.fn.textSlider = function(settings) {
		settings = jQuery.extend({
			speed: "normal",
			line: 2,
			timer: 1000
		},
		settings);
		return this.each(function() {
			$.fn.textSlider.scllor($(this), settings)
		})
	};
	$.fn.textSlider.scllor = function($this, settings) {
		var ul = $("ul:eq(0)", $this);
		var timerID;
		var li = ul.children();
		var _btnUp = $(".up:eq(0)", $this);
		var _btnDown = $(".down:eq(0)", $this);
		var liHight = $(li[0]).height();
		var upHeight = 0 - settings.line * liHight;
		var scrollUp = function() {
			_btnUp.unbind("click", scrollUp);
			ul.animate({
				marginTop: upHeight
			},
			settings.speed,
			function() {
				for (i = 0; i < settings.line; i++) {
					ul.find("li:first").appendTo(ul)
				}
				ul.css({
					marginTop: 0
				});
				_btnUp.bind("click", scrollUp)
			})
		};
		var scrollDown = function() {
			_btnDown.unbind("click", scrollDown);
			ul.css({
				marginTop: upHeight
			});
			for (i = 0; i < settings.line; i++) {
				ul.find("li:last").prependTo(ul)
			}
			ul.animate({
				marginTop: 0
			},
			settings.speed,
			function() {
				_btnDown.bind("click", scrollDown)
			})
		};
		var autoPlay = function() {
			timerID = window.setInterval(scrollUp, settings.timer)
		};
		var autoStop = function() {
			window.clearInterval(timerID)
		};
		ul.hover(autoStop, autoPlay).mouseout();
		_btnUp.css("cursor", "pointer").click(scrollUp);
		_btnUp.hover(autoStop, autoPlay);
		_btnDown.css("cursor", "pointer").click(scrollDown);
		_btnDown.hover(autoStop, autoPlay)
	}
})(jQuery);

// 表情
function grin(a) {
	var d;
	a = " " + a + " ";
	if (document.getElementById("comment") && document.getElementById("comment").type == "textarea") {
		d = document.getElementById("comment")
	} else {
		return false
	}
	if (document.selection) {
		d.focus();
		sel = document.selection.createRange();
		sel.text = a;
		d.focus()
	} else {
		if (d.selectionStart || d.selectionStart == "0") {
			var c = d.selectionStart;
			var b = d.selectionEnd;
			var e = b;
			d.value = d.value.substring(0, c) + a + d.value.substring(b, d.value.length);
			e += a.length;
			d.focus();
			d.selectionStart = e;
			d.selectionEnd = e
		} else {
			d.value += a;
			d.focus()
		}
	}
};

// 弹窗
(function(a) {
	a.fn.extend({
		leanModal: function(d) {
			var e = {
				top: 100,
				overlay: 0.5,
				closeButton: null
			};
			var c = a("<div id='overlay'></div>");
			a("body").append(c);
			d = a.extend(e, d);
			return this.each(function() {
				var f = d;
				a(this).click(function(j) {
					var i = a(this).attr("href");
					a("#overlay").click(function() {
						b(i)
					});
					a(f.closeButton).click(function() {
						b(i)
					});
					var h = a(i).outerHeight();
					var g = a(i).outerWidth();
					a("#overlay").css({
						"display": "block",
						opacity: 0
					});
					a("#overlay").fadeTo(200, f.overlay);
					a(i).css({
						"display": "block",
						"position": "fixed",
						"opacity": 0,
						"z-index": 11000,
						"left": 50 + "%",
						"margin-left": -(g / 2) + "px",
						"top": f.top + "px"
					});
					a(i).fadeTo(200, 1);
					j.preventDefault()
				})
			});
			function b(f) {
				a("#overlay").fadeOut(200);
				a(f).css({
					"display": "none"
				})
			}
		}
	})
})(jQuery);

// 喜欢
$.fn.postLike = function() {
    if (getCookie(location.pathname)==1) {
// 	if (jQuery(this).hasClass("done")) {
	    alert("您已谬赞过了，若收获颇丰，您还可以继续打赏作者！");
	} else {
	    setCookie(location.pathname,1,365);
// 		$(this).addClass("done");
		var d = $(this).data("id"),
		c = $(this).data("action"),
		b = jQuery(this).children(".count");
		var a = {
			action: "zm_ding",
			um_id: d,
			um_action: c
		};
		$.post(wpl_ajax_url, a,
		function(e) {
			jQuery(b).html(e)
		});
		return false
	}
};
$(document).on("click", ".favorite",
function() {
	$(this).postLike()
});

//评论工具条 diy start
$(document).ready(function(){$("#smiley").hide(500);$("#comment-smiley").click(function(){$("#smiley").toggle(500)})});$(document).ready(function(){$("#fontcolor").hide(500);$("#font-color").click(function(){$("#fontcolor").toggle(500)})});$(document).ready(function(){$("#editor").hide(500);$("#comment").click(function(){$("#editor").show(500)})});$(document).ready(function(){$("#smiley").toggle();$("#comment").click(function(){$("#smiley").hide(500)})});$(document).ready(function(){$("#fontcolor").toggle();$("#comment").click(function(){$("#fontcolor").hide(500)})});$(document).ready(function(){$("#smiley").hide();$("#comment").click(function(){})});$(document).ready(function(){$("#fontcolor").hide();$("#comment").click(function(){})});$(function(){function addEditor(a,b,c){if(document.selection){a.focus();sel=document.selection.createRange();c?sel.text=b+sel.text+c:sel.text=b;a.focus()}else{if(a.selectionStart||a.selectionStart=="0"){var d=a.selectionStart;var e=a.selectionEnd;var f=e;c?a.value=a.value.substring(0,d)+b+a.value.substring(d,e)+c+a.value.substring(e,a.value.length):a.value=a.value.substring(0,d)+b+a.value.substring(e,a.value.length);c?f+=b.length+c.length:f+=b.length-e+d;if(d==e&&c){f-=c.length}a.focus();a.selectionStart=f;a.selectionEnd=f}else{a.value+=b+c;a.focus()}}}var myDate=new Date();var mytime=myDate.toLocaleTimeString();var g=document.getElementById("comment")||0;var h={daka:function(){addEditor(g,"签到成功！签到时间："+mytime,"，每日签到，生活更精彩哦~")},strong:function(){addEditor(g,"<strong>","</strong>")},em:function(){addEditor(g,"<em>","</em>")},del:function(){addEditor(g,"<del>","</del>")},underline:function(){addEditor(g,"<u>","</u>")},quote:function(){addEditor(g,"<blockquote>","</blockquote>")},ahref:function(){var a=prompt("请输入链接地址","http://");var b=prompt("请输入要显示成文字链接的描述","");if(a){addEditor(g,'<a target="_blank" href="'+a+'" rel="external nofollow">'+b+"</a>","")}},img:function(){var a=prompt("请输入图片地址","//");if(a){addEditor(g,'<img src="'+a+'" rel="external nofollow" id="comments-img" alt="评论贴图" />',"")}},code:function(){addEditor(g,'<pre class="lang:default">',"</pre>")},red:function(){addEditor(g,"[color=red]","[/color]")},green:function(){addEditor(g,"[color=green]","[/color]")},blue:function(){addEditor(g,"[color=blue]","[/color]")},magenta:function(){addEditor(g,"[color=magenta]","[/color]")},yellow:function(){addEditor(g,"[color=yellow]","[/color]")},chocolate:function(){addEditor(g,"[color=chocolate]","[/color]")},black:function(){addEditor(g,"[color=black]","[/color]")},aquamarine:function(){addEditor(g,"[color=aquamarine]","[/color]")},lime:function(){addEditor(g,"[color=lime]","[/color]")},fuchsia:function(){addEditor(g,"[color=fuchsia]","[/color]")},orange:function(){addEditor(g,"[color=orange]","[/color]")},thistle:function(){addEditor(g,"[color=thistle]","[/color]")},brown:function(){addEditor(g,"[color=brown]","[/color]")},peru:function(){addEditor(g,"[color=peru]","[/color]")},deeppink:function(){addEditor(g,"[color=deeppink]","[/color]")},purple:function(){addEditor(g,"[color=purple]","[/color]")},slategray:function(){addEditor(g,"[color=slategray]","[/color]")},tomato:function(){addEditor(g,"[color=tomato]","[/color]")}};window["SIMPALED"]={};window["SIMPALED"]["Editor"]=h});
//cleanup
$(function(){$("#clean").click(function(){var cache=getCookie(page_name);if(cache!=post_id){CleanUp()}else{artDialog.alert_warning("<br />缓存太顽固，清理没效果？亲，那先喝杯茶休息一下吧~!&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;")}})});function CleanUp(){$.ajax({type:"POST",data:{"action":"delcache","page_url":page_url},url:"/cache.php",cache:false,error:function(){artDialog.alert_warning("<br />发生意外错误！");return false},success:function(){addCookie(page_name,post_id);artDialog.alert_succeed("<br />清理成功！确定后将自动刷新本页（等待几秒命中率更高！）&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;",ReloadPage)}})}function ReloadPage(){location.reload(true)};
//high
function hig(){(function(){function c(){$(".mw_added_css").remove();var e=document.createElement("link");e.setAttribute("type","text/css");e.setAttribute("rel","stylesheet");e.setAttribute("href",f);e.setAttribute("class",l);document.body.appendChild(e)}function h(){var e=document.getElementsByClassName(l);for(var t=0;t<e.length;t++){document.body.removeChild(e[t])}}function p(){var e=document.createElement("div");e.setAttribute("class",a);document.body.appendChild(e);setTimeout(function(){document.body.removeChild(e)},100)}function d(e){return{height:e.offsetHeight,width:e.offsetWidth}}function v(i){var s=d(i);return s.height>e&&s.height<n&&s.width>t&&s.width<r}function m(e){var t=e;var n=0;while(!!t){n+=t.offsetTop;t=t.offsetParent}return n}function g(){var e=document.documentElement;if(!!window.innerWidth){return window.innerHeight}else if(e&&!isNaN(e.clientHeight)){return e.clientHeight}return 0}function y(){if(window.pageYOffset){return window.pageYOffset}return Math.max(document.documentElement.scrollTop,document.body.scrollTop)}function E(e){var t=m(e);return t>=w&&t<=b+w}function S(){$("audio").remove();var e=document.createElement("audio");e.setAttribute("class",l);e.src=i;e.loop=false;e.addEventListener("canplay",function(){setTimeout(function(){x(k)},500);setTimeout(function(){N();p();for(var e=0;e<O.length;e++){T(O[e])}},5000)},true);e.addEventListener("ended",function(){N();h()},true);e.innerHTML=" <p>如果你正在读这篇文章，那是因为你的浏览器不支持音频元素。我们建议你得到一个新的浏览器。</p> <p>";document.body.appendChild(e);e.play()}function x(e){e.className+=" "+s+" "+o}function T(e){e.className+=" "+s+" "+u[Math.floor(Math.random()*u.length)]}function N(){var e=document.getElementsByClassName(s);var t=new RegExp("\\b"+s+"\\b");for(var n=0;n<e.length;){e[n].className=e[n].className.replace(t,"")}}var e=30;var t=30;var n=350;var r=350;
var i=CrazyMusic[Math.floor(Math.random()*Number(CrazyMusic.length))];
var f=hicss;
var s="mw-harlem_shake_me";var o="im_first";var u=["im_drunk","im_baked","im_trippin","im_blown"];var a="mw-strobe_light";var l="mw_added_css";var b=g();var w=y();var C=document.getElementsByTagName("*");var k=null;for(var L=0;L<C.length;L++){var A=C[L];if(v(A)){if(E(A)){k=A;break}}}if(A===null){return}c();S();var O=[];for(var L=0;L<C.length;L++){var A=C[L];if(v(A)){O.push(A)}}})()};function stopCrazy(){$("audio").remove();$(".mw_added_css").remove()};
//Time statistics
function secondToDate(second){if(!second){return 0}var time=new Array(0,0,0,0,0);if(second>=365*24*3600){time[0]=parseInt(second/(365*24*3600));second%=365*24*3600}if(second>=24*3600){time[1]=parseInt(second/(24*3600));second%=24*3600}if(second>=3600){time[2]=parseInt(second/3600);second%=3600}if(second>=60){time[3]=parseInt(second/60);second%=60}if(second>0){time[4]=second}return time}function formatTime(){var create_time=Math.round(new Date(Date.UTC(2013,11,18,0,0,0)).getTime()/1000);var timestamp=Math.round((new Date().getTime()+8*60*60*1000)/1000);currentTime=secondToDate((timestamp-create_time));currentTimeHtml=currentTime[0]+"年"+currentTime[1]+"天"+currentTime[2]+"时"+currentTime[3]+"分"+currentTime[4]+"秒";document.getElementById("run_time").innerHTML=currentTimeHtml};
//title
jQuery(document).ready(function($){$(".like_most a,#related_post_widget a,.list-title a,.archives-list a,#random_post_widget a,#hot_comment_widget a,#hot_post_widget a,.cat-list a, .random-page a").hover(function(){$(this).stop().animate({"marginLeft":"15px"},300)},function(){$(this).stop().animate({"marginLeft":"0px"},300)});$(".like_most a, #related_post_widget a, .list-title a,.archives-list a,#random_post_widget a,#hot_comment_widget a,#hot_post_widget a,.cat-list a, .random-page a").click(function(){myloadoriginal=this.text;$(this).text("正在努力加载中 …");var myload=this;setTimeout(function(){$(myload).text(myloadoriginal)},2011)})});
//监听ESC停止crazy
function KeyMonitor(){if(event.keyCode==27){stopCrazy()}}$(document).dblclick(stopCrazy);$(document).keydown(KeyMonitor);var currentpos,timer;function initialize(){timer=setInterval("scrollwindow()",33)}function sc(){clearInterval(timer)}function scrollwindow(){window.scrollBy(0,1)};
/* document.onmousedown=sc;
 document.ondblclick=initialize; */
try {
	if (window.console && window.console.log) {
		console.log("%c哟，高人您好,祝您扒代码愉快~！","color:red");
		console.log("有问题,请留言：https://zhangge.net/liuyan.html");
		console.log("搞不定,可付费：https://zhangge.net/pay.html");
	};
} catch (e) {};
//printer
var global_Html = "";
function printme() {
	global_Html = document.body.innerHTML;
	document.body.innerHTML = document.getElementById('primary').innerHTML;
	window.print();
	window.setTimeout(function() {
		document.body.innerHTML = global_Html;
	}, 500);
};