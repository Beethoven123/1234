﻿QTags.addButton( 'hr', 'hr', "\n<hr />\n", '' );//添加横线
QTags.addButton( 'h2', 'h2', "\n<h2>", "</h2>\n" ); //添加标题2
QTags.addButton( 'h3', 'h3', "\n<h3>", "</h3>\n" ); //添加标题3
QTags.addButton( 'pre', 'pre', '\n<pre class="prettyprint linenums" >\n', "\n</pre>" );//添加高亮代码
QTags.addButton( 'figure', 'figure', '\n<figure id="attachment_7" style="width: 250px" class="wp-caption alignleft"><figcaption class="wp-caption-text">WordPressLeaf.com</figcaption></figure>\n', "" );
QTags.addButton( 'wangpanl', '网盘', '[download_baidu leaf="" href=""][/download_baidu]', '' ); //添加网盘下载
QTags.addButton( 'github', 'github', '[download_github leaf="" href=""][/download_github]', '' ); //添加github下载
QTags.addButton( 'bendi', '本地', '[download_local leaf="" href=""][/download_local]', '' ); //添加本地下载
QTags.addButton( 'demo', '演示', '[leaf_demo leaf="" href=""][/leaf_demo]', '' ); //添加本地下载
//这儿共有四对引号，分别是按钮的ID、显示名、点一下输入内容、再点一下关闭内容（此为空则一次输入全部内容），\n表示换行。